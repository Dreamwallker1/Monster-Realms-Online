const canvas=document.querySelector('#rig'),ctx=canvas.getContext('2d');
const state={myth:'ashquill',anim:'idle',bones:false,start:performance.now()};
const images={ashquill:new Image(),flarelynx:new Image()};
images.ashquill.src='assets/ashquill_master.png';images.flarelynx.src='assets/flarelynx_master.png';

const rigs={
 ashquill:{scale:1.12,parts:[
  {id:'tail',parent:'body',pivot:[300,350],poly:[[245,292],[500,310],[508,447],[275,408]],z:0,motion:'tail'},
  {id:'wingBack',parent:'body',pivot:[214,252],poly:[[27,142],[231,120],[255,325],[46,353]],z:1,motion:'wingBack'},
  {id:'body',pivot:[256,330],poly:[[130,205],[300,183],[378,308],[343,403],[264,413],[193,374],[145,309]],z:2,motion:'body'},
  {id:'legBack',parent:'body',pivot:[225,350],poly:[[155,320],[267,323],[273,494],[118,494]],z:3,motion:'legBack'},
  {id:'legFront',parent:'body',pivot:[304,351],poly:[[267,316],[373,317],[390,498],[258,496]],z:4,motion:'legFront'},
  {id:'head',parent:'body',pivot:[205,259],poly:[[83,135],[277,121],[292,301],[108,329]],z:5,motion:'head'},
  {id:'wingFront',parent:'body',pivot:[282,250],poly:[[202,16],[498,17],[510,330],[278,339],[220,218]],z:6,motion:'wingFront'}
 ],eye:[156,231],bones:[[256,330,205,259],[256,330,214,252],[256,330,282,250],[256,330,225,350],[256,330,304,351],[256,330,300,350]]},
 flarelynx:{scale:1.1,parts:[
  {id:'tail',parent:'body',pivot:[155,270],poly:[[5,45],[202,45],[222,330],[21,344]],z:0,motion:'tail'},
  {id:'legBack',parent:'body',pivot:[181,313],poly:[[107,273],[232,270],[237,468],[78,471]],z:1,motion:'legBack'},
  {id:'body',pivot:[260,300],poly:[[126,164],[350,148],[410,316],[330,389],[153,356]],z:2,motion:'body'},
  {id:'legFront',parent:'body',pivot:[338,307],poly:[[278,254],[464,258],[477,468],[268,468]],z:3,motion:'legFront'},
  {id:'head',parent:'body',pivot:[326,224],poly:[[218,50],[473,42],[492,304],[216,317]],z:4,motion:'head'}
 ],eye:[357,192],bones:[[260,300,326,224],[260,300,155,270],[260,300,181,313],[260,300,338,307]]}
};

function motion(name,t,anim,myth){
 let r=0,x=0,y=0,s=1;const breathe=Math.sin(t*2.3),fast=Math.sin(t*7);
 if(anim==='idle'){
  if(name==='body')y=breathe*3;
  if(name==='head')r=Math.sin(t*1.7)*.025;
  if(name==='wingFront')r=Math.sin(t*2.1)*.055;
  if(name==='wingBack')r=-Math.sin(t*2.1)*.04;
  if(name==='tail')r=Math.sin(t*2.8)*.065;
  if(name==='legFront'||name==='legBack')r=Math.sin(t*2.3+(name==='legBack'?1:0))*.012;
 }else if(anim==='attack'){
  const p=(t%1.7)/1.7,wind=p<.55?p/.55:(1-p)/.45,hit=Math.max(0,1-Math.abs(p-.62)*15);
  if(name==='body'){x=hit*34;y=-hit*7;r=-hit*.05}
  if(name==='head')r=-wind*.13-hit*.12;
  if(name==='wingFront')r=-wind*.34+hit*.5;
  if(name==='wingBack')r=wind*.28-hit*.35;
  if(name==='tail')r=-wind*.16;
  if(name==='legFront')r=-hit*.28;
 }else{
  const p=(t%1.35)/1.35,hit=Math.max(0,1-p*4),shake=Math.sin(p*70)*hit;
  if(name==='body'){x=-hit*38;r=hit*.12;y=hit*8}
  if(name==='head')r=hit*.22+shake*.03;
  if(name==='wingFront')r=-hit*.3;
  if(name==='wingBack')r=hit*.25;
  if(name==='tail')r=-hit*.25;
 }
 if(myth==='flarelynx'&&name==='wingFront')r=0;
 return{x,y,r,s};
}

function drawPart(img,part,m,origin,scale){
 ctx.save();ctx.translate(origin.x+part.pivot[0]*scale,origin.y+part.pivot[1]*scale);ctx.translate(m.x*scale,m.y*scale);ctx.rotate(m.r);ctx.scale(m.s,m.s);ctx.translate(-part.pivot[0]*scale,-part.pivot[1]*scale);
 ctx.beginPath();part.poly.forEach(([x,y],i)=>(i?ctx.lineTo(x*scale,y*scale):ctx.moveTo(x*scale,y*scale)));ctx.closePath();ctx.clip();ctx.drawImage(img,0,0,512*scale,512*scale);ctx.restore();
}
function drawBones(rig,origin,scale,t){
 ctx.save();ctx.translate(origin.x,origin.y);ctx.strokeStyle='#54ffe1';ctx.fillStyle='#ffdf5b';ctx.lineWidth=2;
 rig.bones.forEach(([ax,ay,bx,by])=>{ctx.beginPath();ctx.moveTo(ax*scale,ay*scale);ctx.lineTo(bx*scale,by*scale);ctx.stroke();for(const [x,y] of [[ax,ay],[bx,by]]){ctx.beginPath();ctx.arc(x*scale,y*scale,5,0,Math.PI*2);ctx.fill()}});ctx.restore();
}
function frame(now){
 const t=(now-state.start)/1000,rig=rigs[state.myth],img=images[state.myth];ctx.clearRect(0,0,canvas.width,canvas.height);
 const scale=rig.scale,origin={x:(canvas.width-512*scale)/2,y:(canvas.height-512*scale)/2+35};
 ctx.save();ctx.globalAlpha=.26;ctx.fillStyle='#ff4d2e';ctx.beginPath();ctx.ellipse(canvas.width/2,590,240,26,0,0,Math.PI*2);ctx.fill();ctx.restore();
 if(img.complete)rig.parts.sort((a,b)=>a.z-b.z).forEach(p=>drawPart(img,p,motion(p.motion,t,state.anim,state.myth),origin,scale));
 if(state.anim==='idle'&&Math.sin(t*.83)>.985){const [ex,ey]=rig.eye;ctx.save();ctx.fillStyle='#170b10';ctx.translate(origin.x,origin.y);ctx.beginPath();ctx.ellipse(ex*scale,ey*scale,11*scale,3*scale,0,0,Math.PI*2);ctx.fill();ctx.restore()}
 if(state.bones)drawBones(rig,origin,scale,t);requestAnimationFrame(frame);
}
document.querySelectorAll('.myth').forEach(b=>b.onclick=()=>{document.querySelectorAll('.myth').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.myth=b.dataset.myth;state.start=performance.now();document.querySelector('#status').textContent=`RIG ACTIVE · ${state.myth.toUpperCase()} · ${state.anim.toUpperCase()}`});
document.querySelectorAll('.anim').forEach(b=>b.onclick=()=>{document.querySelectorAll('.anim').forEach(x=>x.classList.remove('active'));b.classList.add('active');state.anim=b.dataset.anim;state.start=performance.now();document.querySelector('#status').textContent=`RIG ACTIVE · ${state.myth.toUpperCase()} · ${state.anim.toUpperCase()}`});
document.querySelector('#bones').onchange=e=>state.bones=e.target.checked;requestAnimationFrame(frame);
